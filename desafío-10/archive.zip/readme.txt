Iconset: Education (https://www.iconfinder.com/iconsets/education-209)
Author: bamicon (https://www.iconfinder.com/Tempebacem)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
Download date: 2022-04-29